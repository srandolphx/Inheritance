#pragma once
#ifndef SAVINGACCOUNT_H
#define SAVINGACCOUNT_H
#include <string>
#include "BaseAccount.h"



class SavingAccount :
    public BaseAccount
{

public:
  
    SavingAccount(float balance);
    SavingAccount();

    void Withdraw(float amt);

};
#endif


