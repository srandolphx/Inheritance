#pragma once

#include <string>
#include "BaseAccount.h"
class CheckingAccount :
    public BaseAccount
{
public:
    
    CheckingAccount(float balance);
    CheckingAccount();
    void Withdraw(float amt);
private:

};

