#pragma once
#ifndef CREDITACCOUNT_H
#define CREDITACCOUNT_H
#include "BaseAccount.h"
#include<iostream>
#include<string>


class CreditAccount :
    public BaseAccount
{
public:
   
    CreditAccount();

    void Withdraw(float amt);
    double getLimit();
private:
    const static double LIMIT;
    float charge;
    float amount;




};
#endif

