#pragma once
#ifndef ACCOUNT_H
#define ACCOUNT_H
#include <string>
#include <iostream>


using namespace std;

class BaseAccount
{
	float bal;
protected:
	int withDrawls;
private:
	
	float balance;
	static unsigned int numA;
public:

	BaseAccount();
	BaseAccount(float bal);
	void Withdraw(float amount); 
	void Deposit(float amount); 
	float GetBalance() const;
};
#endif


