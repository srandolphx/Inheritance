#include <iostream>
#include <string>
using namespace std;
#include "CreditAccount.h"

const double CreditAccount::LIMIT = 40;

CreditAccount::CreditAccount()
{
	this->charge = 0;
	this->amount = LIMIT;
}

void CreditAccount::Withdraw(float amt)
{
	if (LIMIT - amt < 0)
	{
		cout << "You are now being charged $5000 as punishment for over spending!" << endl;
		this->charge += 5000;
	}
	else {
		this->amount -= amt;
	}
}

double CreditAccount::getLimit()
{
	cout << "Charges :$" << charge << endl;
	return amount;
}
