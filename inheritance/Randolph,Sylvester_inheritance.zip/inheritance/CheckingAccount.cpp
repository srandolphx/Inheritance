#include <iostream>
#include <string>
using namespace std;
#include "CheckingAccount.h"



CheckingAccount::CheckingAccount(float balance) :BaseAccount(balance)
{
}

CheckingAccount::CheckingAccount()
{

}
void CheckingAccount::Withdraw(float amt)
{
	if (withDrawls > 10)
	{
		BaseAccount::Withdraw(amt + 5);
		withDrawls++;
	}
	else
	{
		BaseAccount::Withdraw(amt);
		withDrawls++;
	}
}