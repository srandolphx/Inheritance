#include <iostream>
#include <string>
using namespace std;
#include "SavingAccount.h"

SavingAccount::SavingAccount(float balance) :BaseAccount(balance)
{

}

SavingAccount::SavingAccount()
{

}
void SavingAccount::Withdraw(float amt)
{
	if (withDrawls < 3)
	{
		BaseAccount::Withdraw(amt);
		withDrawls++;
	}
}